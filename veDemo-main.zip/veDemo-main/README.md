This is a demo static website for veDemo
